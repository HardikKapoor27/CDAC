package cdac;

public class TestStudent
{

	public static void main(String[] args) 
	{
		Student s1 = new Student(1001,"nsnathan",40);
		
		s1.displayStudent();
		s1.findResult();
		
		
		Student s2 = new Student(1002,"kumar",50);
		
		s2.displayStudent();
		s2.findResult();
		
//		Student s3 = new Student();
//		
//		s3.displayStudent();
//		s3.findResult();
		
		
		
	}
	
	
}
