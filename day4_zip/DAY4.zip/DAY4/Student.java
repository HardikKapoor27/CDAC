package cdac;

import java.util.Scanner;

public class Student 
{

	int sid;
	String sname;
	int mark;
	
	
	Student()
	{
		System.out.println("enter student details"); 
		
		Scanner s = new Scanner(System.in);
		sid = s.nextInt();
		sname = s.next();
		mark = s.nextInt();
	}
	
	Student(int sid, String sname,int mark)
	{
		this.sid = sid;
		this.sname = sname;
		this.mark = mark;
		
		//this.displayStudent();
	}
	
	
	
	public void displayStudent()
	{
		System.out.print(this.sid +" "+this.sname +" "  + this.mark);
	}
	
	public void findResult()
	{
		if(mark>16)
			System.out.print("  pass");
		else
			System.out.print("  fail");
		System.out.println();
	}
	
	
	
	
}
