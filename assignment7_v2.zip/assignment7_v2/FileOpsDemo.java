import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * Problem 5: Demonstrating Java File Class Methods
 */
public class FileOpsDemo {

    static final String FOLDER_NAME   = "MyFiles";
    static final String ORIGINAL_NAME = "test.txt";
    static final String RENAMED_TO    = "newtest.txt";
    static Scanner userInput = new Scanner(System.in);

    public static void main(String[] args) {
        int sel;
        do {
            System.out.println("\n====== FILE OPERATIONS MENU ======");
            System.out.println("1. Setup Folder and File");
            System.out.println("2. Rename File");
            System.out.println("3. List Folder Contents");
            System.out.println("4. Show File Details");
            System.out.println("5. Exit");
            System.out.print("Select: ");
            sel = userInput.nextInt();
            userInput.nextLine();

            switch (sel) {
                case 1 -> setupFolderAndFile();
                case 2 -> renameTheFile();
                case 3 -> listContents();
                case 4 -> printFileDetails();
                case 5 -> System.out.println("Exiting program.");
                default -> System.out.println("Invalid selection.");
            }
        } while (sel != 5);
    }

    static void setupFolderAndFile() {
        File folder = new File(FOLDER_NAME);
        if (!folder.exists()) {
            if (folder.mkdir()) System.out.println("Folder created: " + folder.getAbsolutePath());
            else { System.out.println("Could not create folder."); return; }
        } else {
            System.out.println("Folder already exists.");
        }

        File newFile = new File(folder, ORIGINAL_NAME);
        try {
            if (newFile.createNewFile()) {
                try (FileWriter fw = new FileWriter(newFile)) {
                    fw.write("Sample content inside test.txt\nCreated for Problem 5.");
                }
                System.out.println("File created: " + newFile.getAbsolutePath());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    static void renameTheFile() {
        File src  = new File(FOLDER_NAME, ORIGINAL_NAME);
        File dest = new File(FOLDER_NAME, RENAMED_TO);

        if (!src.exists()) {
            System.out.println("'" + ORIGINAL_NAME + "' not found. Run Option 1 first.");
            return;
        }
        if (dest.exists()) {
            System.out.println("Already renamed to '" + RENAMED_TO + "'.");
            return;
        }
        System.out.println(src.renameTo(dest)
                ? "Renamed: " + ORIGINAL_NAME + " → " + RENAMED_TO
                : "Rename failed.");
    }

    static void listContents() {
        File folder = new File(FOLDER_NAME);
        if (!folder.exists()) {
            System.out.println("Folder not found. Run Option 1 first.");
            return;
        }
        String[] items = folder.list();
        if (items == null || items.length == 0) {
            System.out.println("Folder is empty.");
            return;
        }
        System.out.println("\nContents of '" + FOLDER_NAME + "':");
        for (String item : items) System.out.println("  > " + item);
    }

    static void printFileDetails() {
        File folder = new File(FOLDER_NAME);
        if (!folder.exists()) {
            System.out.println("Folder not found. Run Option 1 first.");
            return;
        }
        File[] allFiles = folder.listFiles();
        if (allFiles == null || allFiles.length == 0) {
            System.out.println("No files to inspect.");
            return;
        }
        System.out.printf("%n%-20s %-50s %-10s %-8s %-8s%n",
                "Name", "Path", "Bytes", "Read?", "Write?");
        System.out.println("-".repeat(100));
        for (File f : allFiles) {
            System.out.printf("%-20s %-50s %-10d %-8b %-8b%n",
                    f.getName(), f.getAbsolutePath(),
                    f.length(), f.canRead(), f.canWrite());
        }
    }
}
