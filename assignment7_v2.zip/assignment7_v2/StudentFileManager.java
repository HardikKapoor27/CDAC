import java.io.*;
import java.util.Scanner;

/**
 * Problem 1: Writing and Reading Student Names from a Text File
 */
public class StudentFileManager {

    static final String TARGET_FILE = "students.txt";
    static Scanner inputReader = new Scanner(System.in);

    public static void main(String[] args) {
        int option;
        do {
            System.out.println("\n====== STUDENT FILE MENU ======");
            System.out.println("1. Save Names to File");
            System.out.println("2. Load Names from File");
            System.out.println("3. Quit");
            System.out.print("Pick an option: ");
            option = inputReader.nextInt();
            inputReader.nextLine();

            switch (option) {
                case 1 -> saveNames();
                case 2 -> loadNames();
                case 3 -> System.out.println("Bye!");
                default -> System.out.println("Wrong option, try again.");
            }
        } while (option != 3);
    }

    static void saveNames() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(TARGET_FILE))) {
            System.out.println("Type in 5 student names:");
            for (int idx = 1; idx <= 5; idx++) {
                System.out.print("Name #" + idx + ": ");
                String entry = inputReader.nextLine();
                bw.write(entry);
                bw.newLine();
            }
            System.out.println("All names saved to " + TARGET_FILE);
        } catch (IOException ex) {
            System.out.println("Could not write file: " + ex.getMessage());
        }
    }

    static void loadNames() {
        System.out.println("\n--- Names in file ---");
        try (BufferedReader br = new BufferedReader(new FileReader(TARGET_FILE))) {
            String currentLine;
            int lineNum = 1;
            while ((currentLine = br.readLine()) != null) {
                System.out.println(lineNum++ + ". " + currentLine);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("File missing. Save names first (Option 1).");
        } catch (IOException ex) {
            System.out.println("Read error: " + ex.getMessage());
        }
    }
}
