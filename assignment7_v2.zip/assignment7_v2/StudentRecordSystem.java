import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Problem 3: Student Record Management using Object Serialization
 */
public class StudentRecordSystem {

    static final String DATA_FILE = "student.dat";
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int pick;
        do {
            System.out.println("\n===== STUDENT RECORD SYSTEM =====");
            System.out.println("1. Add Student");
            System.out.println("2. Display Students");
            System.out.println("3. Search Student");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");
            pick = sc.nextInt();
            sc.nextLine();

            switch (pick) {
                case 1 -> insertRecord();
                case 2 -> showAllRecords();
                case 3 -> findRecord();
                case 4 -> modifyRecord();
                case 5 -> removeRecord();
                case 6 -> System.out.println("Program closed.");
                default -> System.out.println("Invalid input. Try again.");
            }
        } while (pick != 6);
    }

    // ---- INSERT ----
    static void insertRecord() {
        System.out.print("Roll No  : ");
        int rno = sc.nextInt();
        sc.nextLine();

        List<StudentRecord> records = fetchRecords();
        for (StudentRecord r : records) {
            if (r.getRollNo() == rno) {
                System.out.println("Roll No " + rno + " already exists.");
                return;
            }
        }

        System.out.print("Full Name: ");
        String nm = sc.nextLine();
        System.out.print("Score    : ");
        double sc2 = sc.nextDouble();
        sc.nextLine();

        records.add(new StudentRecord(rno, nm, sc2));
        persistRecords(records);
        System.out.println("Record added!");
    }

    // ---- SHOW ALL ----
    static void showAllRecords() {
        List<StudentRecord> records = fetchRecords();
        if (records.isEmpty()) {
            System.out.println("No records available.");
            return;
        }
        System.out.println("\n" + String.format("%-6s %-15s %s", "RollNo", "Full Name", "Score"));
        System.out.println("=".repeat(35));
        for (StudentRecord r : records) {
            System.out.println(r);
        }
    }

    // ---- FIND ----
    static void findRecord() {
        System.out.print("Enter Roll No to search: ");
        int target = sc.nextInt();
        sc.nextLine();

        for (StudentRecord r : fetchRecords()) {
            if (r.getRollNo() == target) {
                System.out.println("\nRecord Found:");
                System.out.printf("Roll No: %d | Name: %s | Score: %.2f%n",
                        r.getRollNo(), r.getFullName(), r.getScore());
                return;
            }
        }
        System.out.println("No record with Roll No " + target);
    }

    // ---- MODIFY ----
    static void modifyRecord() {
        System.out.print("Enter Roll No to update: ");
        int target = sc.nextInt();
        sc.nextLine();

        List<StudentRecord> records = fetchRecords();
        for (StudentRecord r : records) {
            if (r.getRollNo() == target) {
                System.out.println("Existing -> Name: " + r.getFullName() + " | Score: " + r.getScore());
                System.out.print("New name  (blank = keep): ");
                String newName = sc.nextLine();
                if (!newName.isBlank()) r.setFullName(newName);

                System.out.print("New score (-1 = keep)  : ");
                double newScore = sc.nextDouble();
                sc.nextLine();
                if (newScore >= 0) r.setScore(newScore);

                persistRecords(records);
                System.out.println("Updated successfully!");
                return;
            }
        }
        System.out.println("Roll No " + target + " not found.");
    }

    // ---- REMOVE ----
    static void removeRecord() {
        System.out.print("Enter Roll No to delete: ");
        int target = sc.nextInt();
        sc.nextLine();

        List<StudentRecord> records = fetchRecords();
        boolean found = records.removeIf(r -> r.getRollNo() == target);

        if (found) {
            persistRecords(records);
            System.out.println("Record removed successfully!");
        } else {
            System.out.println("Roll No " + target + " not found.");
        }
    }

    // ---- HELPERS ----
    static List<StudentRecord> fetchRecords() {
        List<StudentRecord> list = new ArrayList<>();
        File f = new File(DATA_FILE);
        if (!f.exists()) return list;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            while (true) {
                try {
                    list.add((StudentRecord) ois.readObject());
                } catch (EOFException e) {
                    break;
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Read error: " + e.getMessage());
        }
        return list;
    }

    static void persistRecords(List<StudentRecord> list) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            for (StudentRecord r : list) oos.writeObject(r);
        } catch (IOException e) {
            System.out.println("Save error: " + e.getMessage());
        }
    }
}
