import java.io.Serializable;

/**
 * Represents a student record stored in the system.
 */
public class StudentRecord implements Serializable {

    private static final long serialVersionUID = 42L;

    private int rollNo;
    private String fullName;
    private double score;

    public StudentRecord(int rollNo, String fullName, double score) {
        this.rollNo = rollNo;
        this.fullName = fullName;
        this.score = score;
    }

    public int getRollNo()           { return rollNo; }
    public String getFullName()      { return fullName; }
    public double getScore()         { return score; }

    public void setFullName(String fullName) { this.fullName = fullName; }
    public void setScore(double score)       { this.score = score; }

    @Override
    public String toString() {
        return String.format("%-6d %-15s %.2f", rollNo, fullName, score);
    }
}
