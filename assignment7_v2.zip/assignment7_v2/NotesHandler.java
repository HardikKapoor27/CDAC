import java.io.*;
import java.util.Scanner;

/**
 * Problem 2: Append and Display Text File Content
 */
public class NotesHandler {

    static final String NOTES_FILE = "notes.txt";
    static Scanner kb = new Scanner(System.in);

    public static void main(String[] args) {
        int opt;
        do {
            System.out.println("\n====== NOTES MENU ======");
            System.out.println("1. Create Note");
            System.out.println("2. Add More to Note");
            System.out.println("3. Show Full Note");
            System.out.println("4. Exit");
            System.out.print("Your choice: ");
            opt = kb.nextInt();
            kb.nextLine();

            switch (opt) {
                case 1 -> createNote();
                case 2 -> addToNote();
                case 3 -> showNote();
                case 4 -> System.out.println("Closing program.");
                default -> System.out.println("Not a valid option.");
            }
        } while (opt != 4);
    }

    static void createNote() {
        try (FileWriter fw = new FileWriter(NOTES_FILE, false)) {
            System.out.print("Enter your note: ");
            String text = kb.nextLine();
            fw.write(text);
            fw.write(System.lineSeparator());
            System.out.println("Note created in " + NOTES_FILE);
        } catch (IOException ex) {
            System.out.println("Write failed: " + ex.getMessage());
        }
    }

    static void addToNote() {
        try (FileWriter fw = new FileWriter(NOTES_FILE, true)) {
            System.out.print("Enter text to add: ");
            String extra = kb.nextLine();
            fw.write(extra);
            fw.write(System.lineSeparator());
            System.out.println("Text added successfully.");
        } catch (FileNotFoundException ex) {
            System.out.println("No note found. Create one first (Option 1).");
        } catch (IOException ex) {
            System.out.println("Append error: " + ex.getMessage());
        }
    }

    static void showNote() {
        System.out.println("\n--- Full Note Content ---");
        try (BufferedReader br = new BufferedReader(new FileReader(NOTES_FILE))) {
            String ln;
            boolean hasContent = false;
            while ((ln = br.readLine()) != null) {
                System.out.println(ln);
                hasContent = true;
            }
            if (!hasContent) System.out.println("(Nothing written yet)");
        } catch (FileNotFoundException ex) {
            System.out.println("File not found. Create a note first (Option 1).");
        } catch (IOException ex) {
            System.out.println("Read error: " + ex.getMessage());
        }
    }
}
