// Addition Operations
#include <iostream>
#include <cmath>
using namespace std;

// Convert binary number (as int) to its decimal equivalent
int binToDec(int num) {
    int result = 0, multiplier = 1;
    while (num > 0) {
        int bit = num % 10;
        result += bit * multiplier;
        multiplier *= 2;
        num /= 10;
    }
    return result;
}

// Convert decimal number to binary representation (as int)
int decToBin(int num) {
    int binVal = 0, place = 1;
    while (num > 0) {
        int remainder = num % 2;
        binVal += remainder * place;
        place *= 10;
        num /= 2;
    }
    return binVal;
}

int main() {
    int opt;
    cout << "--- Addition Menu ---\n";
    cout << "1. Add two integers\n";
    cout << "2. Add two binary numbers\n";
    cout << "3. Add two characters (ASCII)\n";
    cout << "Choose (1-3): ";
    cin >> opt;

    switch (opt) {
        case 1: {
            int x, y;
            cout << "Enter two integers: ";
            cin >> x >> y;
            cout << "Result = " << (x + y) << endl;
            break;
        }
        case 2: {
            int b1, b2;
            cout << "Enter two binary numbers: ";
            cin >> b1 >> b2;
            int d1 = binToDec(b1);
            int d2 = binToDec(b2);
            int total = d1 + d2;
            cout << "Binary sum = " << decToBin(total) << endl;
            break;
        }
        case 3: {
            char c1, c2;
            cout << "Enter two characters: ";
            cin >> c1 >> c2;
            int asciiSum = c1 + c2;
            cout << "ASCII sum = " << asciiSum << endl;
            break;
        }
        default:
            cout << "Invalid option!" << endl;
    }

    return 0;
}
