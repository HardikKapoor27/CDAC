// Swap Two Numbers Using a Temporary Variable
#include <iostream>
using namespace std;

int main() {
    int p, q, hold;
    cout << "Enter two numbers: ";
    cin >> p >> q;

    cout << "Before swap: p = " << p << ", q = " << q << endl;

    hold = p;
    p = q;
    q = hold;

    cout << "After swap: p = " << p << ", q = " << q << endl;
    return 0;
}
