// Find Maximum of Two Numbers
#include <iostream>
using namespace std;

int main() {
    int num1, num2;
    cout << "Enter two numbers: ";
    cin >> num1 >> num2;

    int greater = (num1 > num2) ? num1 : num2;
    cout << "Greater number = " << greater << endl;
    return 0;
}
