// Bitwise Operators Demo
#include <iostream>
using namespace std;

int main() {
    int p, q;
    cout << "Enter two integers: ";
    cin >> p >> q;

    cout << "OR  (|)  = " << (p | q) << endl;
    cout << "AND (&)  = " << (p & q) << endl;
    cout << "XOR (^)  = " << (p ^ q) << endl;
    return 0;
}
