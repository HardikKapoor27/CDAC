// Count Number of Digits
#include <iostream>
using namespace std;

int main() {
    int num, digits = 0;
    cout << "Enter a number: ";
    cin >> num;

    int copy = num;
    if (copy == 0) digits = 1;
    while (copy != 0) {
        copy /= 10;
        digits++;
    }

    cout << "Digit count of " << num << " = " << digits << endl;
    return 0;
}
