// Swap Two Numbers Without a Temporary Variable
#include <iostream>
using namespace std;

int main() {
    int x, y;
    cout << "Enter two numbers: ";
    cin >> x >> y;

    cout << "Before swap: x = " << x << ", y = " << y << endl;

    x = x + y;
    y = x - y;
    x = x - y;

    cout << "After swap: x = " << x << ", y = " << y << endl;
    return 0;
}
