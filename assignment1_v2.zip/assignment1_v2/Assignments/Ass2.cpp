// Compound Interest Calculator
#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double principal, rate, time;
    int freq;

    cout << "Enter principal: ";
    cin >> principal;
    cout << "Enter annual rate (in %): ";
    cin >> rate;
    cout << "Enter time period (years): ";
    cin >> time;
    cout << "Enter compounding frequency per year: ";
    cin >> freq;

    double amount = principal * pow(1 + (rate / 100) / freq, freq * time);
    double compoundInterest = amount - principal;

    cout << "Compound Interest = " << compoundInterest << endl;
    return 0;
}
