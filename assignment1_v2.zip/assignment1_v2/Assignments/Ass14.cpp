// Reverse a Number
#include <iostream>
using namespace std;

int main() {
    int num, rev = 0;
    cout << "Enter a number: ";
    cin >> num;

    int copy = num;
    while (copy != 0) {
        int lastDigit = copy % 10;
        rev = rev * 10 + lastDigit;
        copy /= 10;
    }

    cout << "Reverse of " << num << " = " << rev << endl;
    return 0;
}
