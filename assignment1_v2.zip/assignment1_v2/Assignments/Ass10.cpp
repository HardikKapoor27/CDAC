// Ternary Operator Examples
#include <iostream>
using namespace std;

int main() {
    // Max of two numbers
    int p, q;
    cout << "Enter two numbers: ";
    cin >> p >> q;
    int bigger = (p > q) ? p : q;
    cout << "Maximum = " << bigger << endl;

    // Even or Odd
    int num;
    cout << "Enter a number: ";
    cin >> num;
    string status = (num % 2 == 0) ? "Even" : "Odd";
    cout << num << " is " << status << endl;

    // Largest of three
    int a, b, c;
    cout << "Enter three numbers: ";
    cin >> a >> b >> c;
    int largest = (a > b) ? ((a > c) ? a : c) : ((b > c) ? b : c);
    cout << "Largest = " << largest << endl;

    return 0;
}
