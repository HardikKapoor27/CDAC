// Find Maximum of Three Numbers
#include <iostream>
using namespace std;

int main() {
    int p, q, r;
    cout << "Enter three numbers: ";
    cin >> p >> q >> r;

    int maxVal = (p > q) ? ((p > r) ? p : r) : ((q > r) ? q : r);
    cout << "Maximum = " << maxVal << endl;
    return 0;
}
