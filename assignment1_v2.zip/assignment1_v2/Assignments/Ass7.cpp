// Shift Operator Demo
#include <iostream>
using namespace std;

int main() {
    int val;
    cout << "Enter a number: ";
    cin >> val;

    cout << "Left shift  (val << 2) = " << (val << 2) << endl;
    cout << "Right shift (val >> 2) = " << (val >> 2) << endl;
    return 0;
}
