// Sum of First N Natural Numbers
#include <iostream>
using namespace std;

int main() {
    int limit;
    cout << "Enter n: ";
    cin >> limit;

    int total = limit * (limit + 1) / 2;
    cout << "Sum of first " << limit << " natural numbers = " << total << endl;
    return 0;
}
