// Factorial of a Number
#include <iostream>
using namespace std;

int main() {
    int num;
    cout << "Enter a number: ";
    cin >> num;

    long long fact = 1;
    for (int k = 1; k <= num; k++) {
        fact *= k;
    }

    cout << num << "! = " << fact << endl;
    return 0;
}
