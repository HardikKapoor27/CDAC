// Calculate Area of a Rectangle
#include <iostream>
using namespace std;

int main() {
    double len, wid;
    cout << "Enter length and width of the rectangle: ";
    cin >> len >> wid;

    double rectArea = len * wid;
    cout << "Area = " << rectArea << endl;
    return 0;
}
