// Number Pyramid Pattern
#include <iostream>
using namespace std;

int main() {
    int rows;
    cout << "Enter number of rows: ";
    cin >> rows;

    for (int r = 1; r <= rows; r++) {
        // spaces before numbers
        for (int s = 1; s <= rows - r; s++) {
            cout << " ";
        }
        // increasing side
        for (int k = 1; k <= r; k++) {
            cout << k;
        }
        // decreasing side
        for (int k = r - 1; k >= 1; k--) {
            cout << k;
        }
        cout << "\n";
    }

    return 0;
}
