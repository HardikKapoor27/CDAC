const express = require("express")
const router = express.Router()
const Item = require("../models/Item")

router.get("/", async (req,res) => {
    res.json(await Item.find().sort({ expiryDate: 1}))
})

router.post("/", async (req,res)=> {
    res.json(await new Item(req.body).save())
})

router.delete("/:id", async (req,res) => {
    await Item.findByIdAndDelete(req.params.id)
    res.send("Deleted")
})

router.put("/:id", async (req,res) => {
    res.json(await Item.findByIdAndUpdate(
        req.params.id, req.body, {new:true}))
})

module.exports = router