const express = require('express');
const mongoose = require('mongoose')
const cors = require('cors')

const app = express()
app.use(cors())
app.use(express.json())

mongoose.connect("mongodb://localhost:27017/itemdb")
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log("DB Error:", err))

const routes = require("./routes/itemRoutes")
app.use("/items", routes)

app.listen(5000, () => {
    console.log("Server running on port 5000")
})