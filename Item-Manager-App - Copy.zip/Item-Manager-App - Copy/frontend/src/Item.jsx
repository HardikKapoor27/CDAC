import { useEffect, useState } from "react"
import { getItems, addItem, deleteItem, updateItem } from "./services/api"
import "bootstrap/dist/css/bootstrap.min.css" 

function Item() {
  const [data, setData] = useState([])
  const [form, setForm] = useState({ name:"", cost:"", expiryDate:"", stock:"" })
  const [editId, setEditId] = useState(null)
  const [editForm, setEditForm] = useState({ name:"", cost:"", expiryDate:"", stock:"" })

  const load = async () => { const res = await getItems(); setData(res.data) }
  useEffect(() => { load() }, [])

  const add = async () => { await addItem(form); setForm({ name:"", cost:"", expiryDate:"", stock:"" }); load() }
  const del = async (id) => { await deleteItem(id); load() }
  const startEdit = (i) => { setEditId(i._id); setEditForm({ name:i.name, cost:i.cost, expiryDate:i.expiryDate?.slice(0,10), stock:i.stock }) }
  const update = async (id) => { await updateItem(id, editForm); setEditId(null); load() }

  return (
    <div className="container mt-4" style={{maxWidth:"700px"}}>
      <h3 className="text-center mb-4">Item Manager</h3>

      <div className="row g-2 mb-3">
        <div className="col"><input className="form-control" placeholder="Name"  value={form.name}       onChange={e => setForm({...form, name:e.target.value})} /></div>
        <div className="col"><input className="form-control" placeholder="Cost"  value={form.cost}       onChange={e => setForm({...form, cost:e.target.value})} /></div>
        <div className="col"><input className="form-control" placeholder="Stock" value={form.stock}      onChange={e => setForm({...form, stock:e.target.value})} /></div>
        <div className="col"><input className="form-control" type="date"         value={form.expiryDate} onChange={e => setForm({...form, expiryDate:e.target.value})} /></div>
        <div className="col-auto"><button className="btn btn-primary" onClick={add}>Add</button></div>
      </div>

      <table className="table table-bordered mb-4">
        <thead className="table-dark">
          <tr><th>Name</th><th>Cost</th><th>Stock</th><th>Expiry</th><th>Actions</th></tr>
        </thead>
        <tbody>
          {data.map(i => (
            <tr key={i._id}>
              {editId === i._id ? (
                <>
                  <td><input className="form-control" value={editForm.name}       onChange={e => setEditForm({...editForm, name:e.target.value})} /></td>
                  <td><input className="form-control" value={editForm.cost}       onChange={e => setEditForm({...editForm, cost:e.target.value})} /></td>
                  <td><input className="form-control" value={editForm.stock}      onChange={e => setEditForm({...editForm, stock:e.target.value})} /></td>
                  <td><input className="form-control" type="date" value={editForm.expiryDate} onChange={e => setEditForm({...editForm, expiryDate:e.target.value})} /></td>
                  <td>
                    <button className="btn btn-success btn-sm me-1" onClick={() => update(i._id)}>Save</button>
                    <button className="btn btn-secondary btn-sm"    onClick={() => setEditId(null)}>Cancel</button>
                  </td>
                </>
              ) : (
                <>
                  <td>{i.name}</td><td>{i.cost}</td><td>{i.stock}</td><td>{i.expiryDate?.slice(0,10)}</td>
                  <td>
                    <button className="btn btn-warning btn-sm me-1" onClick={() => startEdit(i)}>Edit</button>
                    <button className="btn btn-danger btn-sm"       onClick={() => del(i._id)}>Delete</button>
                  </td>
                </>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default Item