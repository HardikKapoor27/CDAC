import axios from "axios"

const URL = "http://localhost:5000/items"

export const getItems = () => axios.get(URL)
export const addItem = (data) => axios.post(URL,data)
export const deleteItem = (id) => axios.delete(`${URL}/${id}`)
export const updateItem = (id,data) => axios.put(`${URL}/${id}`, data)